/*
 * (C) Copyright 2016
 * Jelle van der Waa <jelle@vdwaa.nl>
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */
#ifndef _SY8106A_PMIC_H_

int sy8106a_set_vout1(unsigned int mvolt);

#endif
