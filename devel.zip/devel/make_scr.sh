#!/bin/sh
./mkimage -C none -A arm -T script -d boot.cmd boot.scr
