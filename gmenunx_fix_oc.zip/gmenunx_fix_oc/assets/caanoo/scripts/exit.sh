#!/bin/sh
cd /
umount /usr/gp2x
cd /usr/gp2x
./gp2xmenu
